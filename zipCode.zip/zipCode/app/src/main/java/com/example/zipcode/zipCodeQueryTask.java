package com.example.zipcode;

interface zipCodeQueryTask {
}
