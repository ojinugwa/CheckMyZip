package com.example.zipcode;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class RepFragment extends Fragment {

    private static final String TAG = "repElectActivity";
    private static final String API = "AIzaSyAzktmKV8TyiQpxZlZgOMb3613v2JAV6f8";


    //Vars
    private ArrayList<String> roles = new ArrayList<>();
    private ArrayList<String> names = new ArrayList<>();

    View v;
    private RecyclerView recyclerView;


    //private static final String TAG = "NewsActivity";

    //Vars
    private ArrayList<String> headLine = new ArrayList<>();
    private ArrayList<String> mImagesUrls = new ArrayList<>();

    public RepFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //imageBit();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_rep, container, false);
        //recyclerView= v.findViewById(R.id.fragment_news_view);
        recyclerView = (RecyclerView) v.findViewById(R.id.rep_recylcer);
        RepRecyclerAdapter repRecyclerAdapter = new RepRecyclerAdapter(roles, names, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(repRecyclerAdapter);

        return v;
    }


    public class fetchData extends AsyncTask<Void, Void, Void> {


        String data = "";


        String dataParsed = "";


        String singleParsed = "";


        String zipurl = "";


        @Override


        protected Void doInBackground(Void... voids) {


            try {


                URL url = new URL(zipurl);


                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                InputStream inputStream = httpURLConnection.getInputStream();


                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));


                String line = "";


                while (line != null) {


                    line = bufferedReader.readLine();


                    data = data + line;


                }


                //JSONArray jsonArray = new JSONArray(data);


                JSONObject obj = new JSONObject(data);


                JSONArray jsonArray = new JSONArray();


                jsonArray = obj.getJSONObject("datafinder").getJSONArray("results");


                for (int i = 0; i < jsonArray.length(); i++) {


                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);

                    roles.add("offices: " + jsonObject.get("name"));
                    names.add("officials: " + jsonObject.get("name"));

                }


            }
                catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (JSONException exception) {
                    exception.printStackTrace();
                } catch (IOException exception) {
                    exception.printStackTrace();
                }
            return null;
        }
        protected void onPostExecute(Void... aVoid) {

            super.onPostExecute(null);
        }


        public void setZipcode(String zipcode) {
            //zipurl="https://api.myjson.com/bins/pit9s";
            zipurl = "https://www.googleapis.com/civicinfo/v2/representatives?address=" + zipcode + "&key=AIzaSyAzktmKV8TyiQpxZlZgOMb3613v2JAV6f8";
        }
    }
}