package com.example.zipcode;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class WeatherFragment extends Fragment {


    private static final String TAG = "MainActivity";

    //ErrorMessage during Buffer
    TextView queryErrorMessage;

    //Progress bar while query is waiting for result
    private ProgressBar queryLoadingIndicator;
    TextView showResults;

    //Vars
    private ArrayList<String> date = new ArrayList<>();
    private ArrayList<String> current_temp = new ArrayList<>();
    private ArrayList<String> min_temp = new ArrayList<>();
    private ArrayList<String> max_temp = new ArrayList<>();
    private ArrayList<String> description = new ArrayList<>();
    //private ArrayList<String> mImagesUrls = new ArrayList<>();



    View v;
    RecyclerView recyclerView;
    String zipCode = "10550";
    String API = "7bbf84c06241db26372120b5cb54bd7f";

    public WeatherFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_weather, container, false);

        recyclerView = (RecyclerView) v.findViewById(R.id.weather_recycler);
        WeatherRecyclerAdapter weatherRecyclerAdapter = new WeatherRecyclerAdapter(description, date, min_temp, max_temp, current_temp, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(weatherRecyclerAdapter);
        //recyclerView = (RecyclerView) recyclerView.findViewById(R.layout.news_news);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //imageBit();
    }



    /*
    private void imageBit(){

        //URL url = new URL()
        try{
            JSONObject jsonObject = getJSONObjectFromURL ("https://api.openweathermap.org/data/2.5/forecast?zip=10550&appid=a03ccfd93b214850782be044d4671ab9");
            // "http://api.openweathermap.org/data/2.5/weather?zip=" + zipCode + "&appid=" + API);

            // Parse your json here
           // JSONArray values = jsonObject.getJSONArray("list");

            /*for (int i = 0; i > values.length(); i++ ){
                description.add("kkefbvsj");
                date.add("jdssvs");
                min_temp.add("isvsv");
                max_temp.add("ksfgsvs");
                current_temp.add("ksfgsvs");
            }

            if ( values.length() > 0 ){
                description.add("k");
                date.add("jdssvs");
                min_temp.add("isvsv");
                max_temp.add("ksfgsvs");
                current_temp.add("ksfgsvs");
            }

            description.add("kkefbvsj");
            date.add("jdssvs");
            min_temp.add("isvsv");
            max_temp.add("ksfgsvs");
            current_temp.add("ksfgsvs");


            description.add("abuja");
            date.add("7th");
            min_temp.add("40");
            max_temp.add("60");
            current_temp.add("80");
            //
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public JSONObject getJSONObjectFromURL(String urlString) throws IOException, JSONException {
        //String response = "https://api.openweathermap.org/data/2.5/daily?zip=" + zipCode + "&appid=" + API;


        HttpURLConnection urlConnection = null;
        URL url = new URL(urlString);
        urlConnection = (HttpURLConnection) url.openConnection();
        urlConnection.setRequestMethod("GET");
        urlConnection.setReadTimeout(10000 /* milliseconds */ /*);
        //urlConnection.setConnectTimeout(15000 /* milliseconds */ /*);
    /*
        urlConnection.setDoOutput(true);
        urlConnection.connect();

        BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
        StringBuilder sb = new StringBuilder();

        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line + "\n");
        }
        br.close();

        String jsonString = sb.toString();
        System.out.println("JSON: " + jsonString);

        return new JSONObject(jsonString);
    }*/


    public class zipCodeQueryTask extends AsyncTask<URL, Void, String> implements com.example.zipcode.zipCodeQueryTask {

        @Override
        protected String doInBackground(URL... urls) {
            try {
                JSONObject getresult = gatherInfo("https://api.openweathermap.org/data/2.5/forecast?zip=10550&appid=a03ccfd93b214850782be044d4671ab9");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            queryLoadingIndicator.setVisibility(View.VISIBLE);
        }

        //@Override
        protected JSONObject gatherInfo(String urlString) throws IOException, JSONException {

            HttpURLConnection urlConnection = null;
            URL url = new URL(urlString);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setReadTimeout(10000 /* milliseconds */);
            //urlConnection.setConnectTimeout(15000 /* milliseconds */ );

            urlConnection.setDoOutput(true);
            urlConnection.connect();

            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            br.close();

            String jsonString = sb.toString();
            System.out.println("JSON: " + jsonString);

            return new JSONObject(jsonString);
        }

        @Override
        protected void onPostExecute(String searchResults) {
            //Hide the loading signal after items already load
            queryLoadingIndicator.setVisibility(View.INVISIBLE);

            if (searchResults != null && !searchResults.equals("")){

                showJsonDataView();
                showResults.setText(searchResults);
            }
            else{
                showErrorMessage();
            }
        }
    }

    /**Shows Jason Data **/
    private void showJsonDataView(){
        queryErrorMessage.setVisibility(View.INVISIBLE);
        showResults.setVisibility(View.VISIBLE);
    }

    /**Shows Error message if results are not gotten from Query**/
    private void showErrorMessage(){
        queryErrorMessage.setVisibility(View.VISIBLE);
        showResults.setVisibility(View.INVISIBLE);
    }

    public JSONObject getJSONObjectFromURL(String urlString) throws IOException, JSONException {
        //String response = "https://api.openweathermap.org/data/2.5/daily?zip=" + zipCode + "&appid=" + API;


        HttpURLConnection urlConnection = null;
        URL url = new URL(urlString);
        urlConnection = (HttpURLConnection) url.openConnection();
        urlConnection.setRequestMethod("GET");
        urlConnection.setReadTimeout(10000 /* milliseconds */);
        //urlConnection.setConnectTimeout(15000 /* milliseconds */ );

        urlConnection.setDoOutput(true);
        urlConnection.connect();

        BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
        StringBuilder sb = new StringBuilder();

        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line + "\n");
        }
        br.close();

        String jsonString = sb.toString();
        System.out.println("JSON: " + jsonString);

        return new JSONObject(jsonString);
    }
}
