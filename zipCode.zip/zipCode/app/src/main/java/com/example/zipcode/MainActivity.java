package com.example.zipcode;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {


    private TabLayout tabLayout;
    private ViewPagerAdapter viewPagerAdapter;
    private ViewPager viewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        //Adding Fragments
        viewPagerAdapter.AddFragment(new MainFragment(), "News");
        viewPagerAdapter.AddFragment(new WeatherFragment(), "Weather");
        viewPagerAdapter.AddFragment(new RepFragment(),"Official Elect");


        viewPager.setAdapter(viewPagerAdapter);
        tabLayout.setupWithViewPager(viewPager);

        //Adding the Icons
        tabLayout.getTabAt(0).setIcon(R.drawable.news_icon);
        tabLayout.getTabAt(1).setIcon(R.drawable.weather_icon);
        tabLayout.getTabAt(2).setIcon(R.drawable.rep_icon);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
    }
}
